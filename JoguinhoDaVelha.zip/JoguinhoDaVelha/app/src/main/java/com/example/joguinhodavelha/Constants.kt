package com.example.joguinhodavelha

const val BD_NOME = "PDM_SQLite"
const val BD_VERSAO = 1
const val TBL_USUARIO = "usuario"
const val TBL_USUARIO_ID =  "_id"
const val TBL_USUARIO_LOGIN = "login"
const val TBL_USUARIO_SENHA = "senha"

const val TBL_USUARIO_JOGO = "usuario_jogo"
const val TBL_USUARIO_JOGO_ID =  "__id"
const val TBL_USUARIO_IDU =  "_idu"
const val TBL_USUARIO_JOGO_COUNT = "plays"

const val TBL_JOGO = "jogo"
const val TBL_JOGO_ID =  "___id"
const val TBL_JOGO_PLAYER1 =  "jogador1"
const val TBL_JOGO_PLAYER2 =  "jogador2"
const val TBL_JOGO_WINNER =  "vencedor"